package Arrays;

public class Strings {

	public static void main(String[] args) {
		String s1= "Welcome";
		String s2= "To USA!";
		
		System.out.println(s1.length());
		System.out.println(s1.concat(s2));
		
		String t = "Welcome";
System.out.println(t.trim());
System.out.println(t.charAt(6));
System.out.println(t.contentEquals("Welcome"));
System.out.println(t.equalsIgnoreCase("welcome"));

	}

}
