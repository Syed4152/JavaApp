package OopsConcepts;

public class Employee {

	int employId;
	String empName;
	double sal;
	int depNumber;
	String job;

	void display() {
		System.out.println(employId);
		System.out.println(empName);
		System.out.println(sal);
		System.out.println(depNumber);
		System.out.println(job);
	}
	


}
