package OopsConcepts;

public class StudnetMain {

	public static void main(String[] args) {
		
		Student stu1 = new Student(101, "Mohammed", 'A');
		stu1.display();
		
		
		/* stu1.id= 121;
		stu1.studentName ="Mohammed";
		stu1.grade='A';
		stu1.display();
		*/
		
		 /*stu1.getValues(1011, "Mohammed", 'A');
		stu1.display();
		*/
		
		
		

	}

}
