package ClassA;

public class TestCase001 {
	
public static void main( String args[] ) {
	System.out.println("Hey");
	
               }

}
