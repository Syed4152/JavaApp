package ClassA;

public class DataTypes {

	public static void main(String args[]) {
		int a = 10;
		double d= 20.5;
		char t = 'H';
		boolean b= true;
		
		String s="Welcome!";
		
		System.out.println(a);
		System.out.println(d);
		System.out.println(b);
		System.out.println(t);
		
	}

}
