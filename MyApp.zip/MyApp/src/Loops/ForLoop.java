package Loops;

public class ForLoop {

	public static void main(String[] args) {
		/* Initialize the variable with starting value.
		 * Condition is required.
		 * increment or decrement is required. 
		 * In for loop you define all the above three statement in just one statement itself. 
		 * example: for(initialization:Condition;Incrementation/Decrementation)
		 */
		for(int i=6; i<=52; i+=2)
			{
			System.out.println(i);
		}
	}

}


