package MethodOverLoading;

public class InheritanceExamples {
	public static void main(String[] args) {
	}
}