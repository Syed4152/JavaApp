package MethodOverLoading;

public class MethodOverriding {

	public static void main(String[] args) {

	}
}
